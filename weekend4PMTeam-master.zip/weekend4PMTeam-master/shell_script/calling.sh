#testiing the git revert in the session
./var.sh $1 $1

echo "welcome"

echo "welcome1"
