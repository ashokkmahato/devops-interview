
#Check whether they are equal
if [ $1 == "beginner" ]
then
    echo "entered value is beginner"
else
  echo "entered value is not beginner, it is actually $1"
fi