#!/bin/bash
read -p 'Username: ' uservar
read -p 'Env: ' envvar
read -sp 'Enter password: ' passvar
echo
echo Thank you $uservar we would be deploying application into $envvar enviroment
echo "Welcome"
