#!/bin/sh
firstvar=$1
secondvar=$2
echo "welcome $firstvar & $secondvar to this session of devops "

